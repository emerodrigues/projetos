package tela;

public class TelaPrincipal {

	// Tudo come�a a partir de um MAIN!!!
	public static void main(String[] args) {
		
	}
}
