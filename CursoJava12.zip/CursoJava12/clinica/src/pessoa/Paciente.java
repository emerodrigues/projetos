package pessoa;

public class Paciente {

}
