package pessoa;

public class Medico {

}
