package controle;

public class Break {

	// tecnica para debugar 
	// F6 avan�a F8 pula
	// habilitar Variables e Expressions pra ajudar	
	
	public static void main(String[] args) {
		
		for (int i = 0; i < 10; i++) {
			if(i == 5) {
				break;
			}
			System.out.println(i);
		}
			System.out.println("Fim!");
	}
}
