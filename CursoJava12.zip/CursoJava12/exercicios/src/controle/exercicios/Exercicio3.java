package controle.exercicios;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);

		System.out.println("Digite a 1� nota");
		double nota1 = entrada.nextDouble();
		
		System.out.println("Digite a 2� nota");
		double nota2 = entrada.nextDouble();
		
		double media = (nota1 + nota2) / 2;
		if (media >= 7) {
			System.out.println("Aprovado " + media);
		} else if (media > 4) {
			System.out.println("Recupera��o " + media);
		} else {
			System.out.println("Reprovado " + media);
		}
		
		entrada.close();
	} 
}
