package controle.exercicios;

public class Exercicio2 {

	public static void main(String[] args) {

		int ano = 2022;
		
		if (ano % 4 == 0) {
			System.out.println("Ano Bissexto");
		} else {
			System.out.println("O ano nao � bissexto");
		}
	}

}
