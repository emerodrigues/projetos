package controle;

public class For3 {

	public static void main(String[] args) {
		
		// executar no modo debug -- F6 avan�a -- F8 avan�a p prox breakpoint
		
		for(int i = 0; i < 10; i++) {
			for(int j = 0; j < 10; j++) {
				System.out.printf("[%d %d]\n",i,j);
			}
			//System.out.println();
		}
	}
}
