package controle;

public class DesafioFor {

	public static void main(String[] args) {
		
//		String valor = "#";
//		for (int i = 1; i <= 5; i++ ) {
//			System.out.println(valor);
//			// valor = valor # + valor # 
//			valor += "#";
//			
//			// Nao pode usae valor numerico para controlar o la�o!
//		}
		
		
		for(String v = "#"; !v.equals("######"); v += "#") {
			System.out.println(v);
		}
		
		int i = 1;
		while(i < 10) {
			System.out.println("i = " + i);
			i++;
		}
	}
}
