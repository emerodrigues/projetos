package controle;

public class WhileDeterminado {

	public static void main(String[] args) {
		
		// While pode ou nao passar pelo loop
		
		int contador = 1;
		while(contador <= 10) {
			System.out.printf("i = %d\n", contador);
			//contador++;
			contador += 2;
		}
	}

}
