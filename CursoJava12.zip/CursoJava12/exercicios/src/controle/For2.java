package controle;

public class For2 {

	public static void main(String[] args) {
		
		// criar um for decrecente de 2 em 2
		
		for(int contador = 10; contador >= 0 ;contador-=2) {
			System.out.printf("i = %d\n", contador);
		}
	}

}
