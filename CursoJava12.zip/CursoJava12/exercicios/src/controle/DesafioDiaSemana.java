package controle;

import java.util.Scanner;

public class DesafioDiaSemana {

	public static void main(String[] args) {
		
		// digitar Domingo -> 1 
		// digitar Segunda -> 2
		
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o nome do dia");
		String dia = entrada.nextLine();
		
		if(dia.equalsIgnoreCase("domingo")) {
			System.out.println(1);
		} else if (dia.equalsIgnoreCase("segunda")) {
			System.out.println(2);
		} else if (dia.equalsIgnoreCase("ter�a")) {
			System.out.println(3);
		} else if (dia.equalsIgnoreCase("quarta")) {
			System.out.println(4);
		} else if (dia.equalsIgnoreCase("quinta")) {
			System.out.println(5);
		} else if (dia.equalsIgnoreCase("sexta")) {
			System.out.println(6);
		} else if ("s�bado".equalsIgnoreCase(dia) 
					|| "sabado".equals(dia)) {
			System.out.println(7);
		} else {
			System.out.println("Dia inv�lido");
		}
		
		entrada.close();
	}
}
