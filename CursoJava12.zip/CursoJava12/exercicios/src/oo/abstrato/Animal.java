package oo.abstrato;

public abstract class Animal {
	
	public String respirar() {
		return "Usando oxig�nio";
	}
	
	public abstract String mover();
}
