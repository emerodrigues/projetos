package oo.heranca.desafio;

public interface Esportivo {

	public abstract void ligarTurbo();
	public abstract void desligarTurbo();
	
}
