package oo.heranca.desafio;

public abstract interface Luxo {

	public abstract void ligarAr();
	public abstract void desligarAr();
	
	default int velocidadeDoAr() {
		return 1;
	}
}
