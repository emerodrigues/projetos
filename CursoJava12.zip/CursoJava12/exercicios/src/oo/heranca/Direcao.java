package oo.heranca;

public enum Direcao {
	
	NORTE, 
	LESTE,
	SUL,
	OESTE;
}
