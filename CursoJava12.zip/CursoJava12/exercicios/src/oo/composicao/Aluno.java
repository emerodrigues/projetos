package oo.composicao;

import java.util.ArrayList;
import java.util.List;

public class Aluno {

	final String NOME;
	final List<Curso> cursos = new ArrayList<>();
	
	Aluno(String nome) {
		this.NOME = nome;
	}
	
	//bidirecional
	void addCursos(Curso curso) {
		this.cursos.add(curso);
		curso.alunos.add(this);
	}
	
	Curso getCursoNome(String nome) {
		for (Curso curso: this.cursos) {
			if(curso.NOME.equalsIgnoreCase(nome)) {
				return curso;
			}
		}
		return null;
	}
	
	public String toString() {
		return NOME;
	}
}
