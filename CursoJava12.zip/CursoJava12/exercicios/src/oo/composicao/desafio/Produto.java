package oo.composicao.desafio;

public class Produto {

	final String nomeProduto;
	final double preco;
	
	Produto(String nome, double preco) {
		this.nomeProduto = nome;
		this.preco = preco;
	}
}
