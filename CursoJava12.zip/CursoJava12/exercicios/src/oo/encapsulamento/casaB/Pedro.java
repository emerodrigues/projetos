package oo.encapsulamento.casaB;

import oo.encapsulamento.casaA.Ana;

public class Pedro extends Ana {

	void testeAcessos() {
//		System.out.println(segredo); privado
//		System.out.println(facoDentroDeCasa); //mesmo pacote
		System.out.println(formaDeFalar); 
		System.out.println(todosSabem);
		System.out.println(new Ana().todosSabem);
	}
}
