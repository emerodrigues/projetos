package colecoes;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Mapa {

	public static void main(String[] args) {
		
		Map<Integer, String> usuarios = new HashMap<>();
		usuarios.put(1, "Roberto");
		usuarios.put(1 , "Ricardo Amaro");
		usuarios.put(2 , "Rafaela");
		usuarios.put(3 , "Rebecca");
		usuarios.put(4 , "Rafael");
		
		System.out.println("Tamanho do Map: " + usuarios.size());
		System.out.println(usuarios.isEmpty());
		System.out.println(usuarios.keySet());
		System.out.println(usuarios.values());
		System.out.println(usuarios.entrySet()); // vem os dois dados
		
		System.out.println(usuarios.containsKey(20));
		System.out.println(usuarios.containsKey(3));
		System.out.println(usuarios.containsValue("Rafaela"));
		System.out.println(usuarios.remove(4));
		
		System.out.println(usuarios.get(2));
		
		for(Integer chave: usuarios.keySet()) {
			System.out.println("Total de usuarios: " + chave);
		}
		for(String valor: usuarios.values()) {
			System.out.println("Total de usuarios: " + valor);
		}
		for(Entry<Integer, String> registro: usuarios.entrySet()) {
			System.out.print(registro.getKey() + " ==> " );
			System.out.println(registro.getValue());
		}
		
	}

}
