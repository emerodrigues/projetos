package colecoes;

import java.util.LinkedList;
import java.util.Queue;

public class Fila {

	public static void main(String[] args) {
		
		Queue<String> fila = new LinkedList<>();
		
		fila.add("Ana");
		fila.offer("Bia");
		fila.add("Carlos");
		fila.add("Daniel");
		fila.add("Rafaela");
		fila.add("Gui");
		
		System.out.println(fila.peek());
		System.out.println(fila.peek());
		System.out.println(fila.element());
		
		//fila.clear();
		//fila.isEmpty();
		//fila.size();
		//fila.contains();
		
		
		System.out.println(fila.poll());
		System.out.println(fila.remove()); // lan�a exce��o
		System.out.println(fila.poll());
		System.out.println(fila.poll()); // retorna false
		System.out.println(fila.poll());
		System.out.println(fila.poll());
		System.out.println(fila.poll());
		
	}
}
