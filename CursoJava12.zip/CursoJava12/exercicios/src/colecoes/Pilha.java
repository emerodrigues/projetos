package colecoes;

import java.util.ArrayDeque;
import java.util.Deque;

public class Pilha {

	public static void main(String[] args) {

		Deque<String> livros = new ArrayDeque<String>();
		
		livros.add("O pequeno Pr�ncipe");
		livros.push("Don Quixote");
		livros.push("O Hobbit");
		
		System.out.println(livros.size());
		System.out.println(livros.peek()); //exibem o ultimo da fila
		System.out.println(livros.element());

		for(String livro: livros) {
			System.out.println(livro);
		}
		
		System.out.println("Removeu o livro: " + livros.poll()); //remove
		System.out.println(livros.size());
		
		System.out.println("Removeu o livro: " + livros.remove());
		System.out.println(livros.size());
		
		System.out.println("Removeu o livro: " + livros.pop());
		
		System.out.println(livros.size());
	
	}
}
