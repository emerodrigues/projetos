package fundamentos;

public class Wrappers {

	public static void main(String[] args) {
		//
		Byte b = 100;
		Short s = 1000;
		Integer i = Integer.parseInt("1000"); // int
		Long l = 1000000L;

		System.out.println(b.byteValue());
		System.out.println(s.toString());
		System.out.println(i);
		System.out.println(l);
		
		Float f = 123F;
		System.out.println(f);
		
		Double d = 1234.5678;
		System.out.println(d);
		
		Boolean bo = Boolean.parseBoolean("true");
		System.out.println(bo);
		System.out.println(bo.toString().toUpperCase());

		Character c = '#';
		System.out.println(c);
		
	}
}
