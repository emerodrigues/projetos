package fundamentos;

import java.util.Scanner;

public class DesafioConversao {

	public static void main(String[] args) {
		
		//Criar um Scaner, pegar 3 strings utilizando o nextLine 
		// receber os ultimos 3 salarios de um funcionario e calcular 
		// a media do salario.  Conveter a string em um valor numero aceitar . e ,
		 
		Scanner entrada = new Scanner(System.in);
		System.out.println("Informe o seu 1� salario: ");
		String salario1 = entrada.nextLine().replace(",", ".");
		
		System.out.println("Informe o seu 2� salario: ");
		String salario2 = entrada.nextLine().replace(",", ".");
		
		System.out.println("Informe o seu 3� salario: ");
		String salario3 = entrada.nextLine().replace(",", ".");		
		
		double numero1 = Double.parseDouble(salario1);
		double numero2 = Double.parseDouble(salario2);
		double numero3 = Double.parseDouble(salario3);
		
		double media = (numero1 + numero2 + numero3) / 3;
		
		System.out.println("Sua media �: "+ media);
		entrada.close();
	}
}
