package fundamentos;

public class TipoString {

	public static void main(String[] args) {
		System.out.println("Ola pessoa".charAt(0));
		
		var nome = "Emerson";
		var sobrenome = "Silva";
		var idade = 25;
		
		System.out.printf("Meu nome � %s %s %s", nome, sobrenome, idade);
		
	}
}
