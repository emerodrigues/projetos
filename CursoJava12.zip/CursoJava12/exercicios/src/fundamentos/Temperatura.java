package fundamentos;

public class Temperatura {

	public static void main(String[] args) {
		// (F - 32) x 5/9.0 = C
		//informar um valor subtraindo -32 X 5/9 = C
		// 32 constante ajuste ou diferenca
		// 5/9 constante fator
		// F e C variavel
		
		final int AJUSTE = 32;
		final double FATOR = 5/9.0;
		double f = 86;
		
		double c = (f - AJUSTE) * FATOR ;
		System.out.println("O resultado �: " + c);
		
		f = 150;
		c = (f - AJUSTE) * FATOR ;
		System.out.println("O resultado �: " + c);
	}		
}
