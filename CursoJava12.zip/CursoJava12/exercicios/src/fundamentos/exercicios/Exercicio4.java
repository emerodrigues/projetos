package fundamentos.exercicios;

import java.util.Scanner;

/**
 * Criar um programa que leia um 
 * valor e apresente os resultados ao 
 * quadrado e ao cubo do valor.
 */

public class Exercicio4 {

	public static void main(String[] args) {
				
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite um numero");
		double numeroInformado = entrada.nextDouble();
		
		double quadrado = Math.pow(numeroInformado, 2);
		//double quadrado = numeroInformado * numeroInformado;
		System.out.println("O valor ao quadrado � " + quadrado);
		
		double cubo = Math.pow(numeroInformado, 3);
		//double cubo = numeroInformado * numeroInformado * numeroInformado;
		System.out.println("O valor ao cubo � " + cubo);
		
		entrada.close();
		
	}
}
