package fundamentos.exercicios;

import java.util.Scanner;

/**
 * Criar um programa que leia a 
 * temperatura em Celsius e converta 
 * para Fahrenheit.
 *
 */

public class Exercicio1 {

	public static void main(String[] args) {
		
	Scanner scanner = new Scanner(System.in);
	
	System.out.println("Digite a temperatura em Celsius");
	double celsius = scanner.nextDouble();
	
	double conversao = (celsius - 32) / 1.8; 
	
	System.out.println("Valor em Farenheit"+ conversao);
	
	scanner.close();
	
	}
}
