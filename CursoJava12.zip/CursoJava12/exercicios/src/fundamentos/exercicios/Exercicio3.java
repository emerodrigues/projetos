package fundamentos.exercicios;

import java.util.Scanner;

/**
 * @author emerodrigues
 *Criar um programa que leia o 
 *peso e a altura do usu�rio e 
 *imprima no console o IMC
 */

public class Exercicio3 {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o seu peso");
		double peso = entrada.nextDouble();
		
		System.out.println("Digite a sua altura");
		double altura = entrada.nextDouble();
		
		double imc = peso / (altura * altura);
		//System.out.println("Seu IMC �: " + imc);		
		System.out.printf("Seu IMC �: %.2f", imc);
		
		entrada.close();
	}
}
