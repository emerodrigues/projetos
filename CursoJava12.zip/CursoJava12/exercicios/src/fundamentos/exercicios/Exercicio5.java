package fundamentos.exercicios;

import java.util.Scanner;

public class Exercicio5 {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o valor da base");
		double base = entrada.nextDouble();
		
		System.out.println("Digite o valor da altura");
		double altura = entrada.nextDouble();
		
		double area = (base * altura) / 2;
		System.out.println("O valor da area e " + area);
		
		entrada.close();
	}
}
