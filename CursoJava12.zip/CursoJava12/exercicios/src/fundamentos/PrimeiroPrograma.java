package fundamentos;

/**
 * Essa classe faz... JAVADOC 
 * @author Emerson Rodrigues da Silva
 * 
 */

public class PrimeiroPrograma {
	
	/**
	 * 
	 * @param args
	 */

	 public static void main(String[] args) {
		
		 // Retirar idioma ingles 
		 System.out.println("Primeiro programa");
		 
	}
}
