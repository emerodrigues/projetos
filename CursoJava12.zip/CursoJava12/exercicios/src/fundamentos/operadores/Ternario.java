package fundamentos.operadores;

public class Ternario {
	
	public static void main(String[] args) {
		
		// O Operador Tern�rio verifica 
		// uma condi��o e retorna um dentre dois valores 
		// pr�-definidos em sua estrutura
		
		double media = 8.6;
//		String resultadoParcial = media >= 7.0 ? 
//				"aprovado" : "em recupera��o";
		String resultadoFinal = media >= 5.0 ? 
				"em recupera��o" : "reprovado";
		
		System.out.println("O aluno est�: " + resultadoFinal);
	}
}
