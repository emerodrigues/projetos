package fundamentos.operadores;

public class DesafioAritmeticos {

	public static void main(String[] args) {

//		int a = 3 * 4 - 10;
//		double b = Math.pow(a, 3);
//		int c =  (int) Math.pow(a, 2);
//		
//		System.out.println(b);
//		System.out.println(c);

		double b = Math.pow(6 * (3 + 2), 2);

//		int a = 6 * (3 + 2);
//		int b = (int) Math.pow(a, 2);

		int c = 3 * 2;
		double d = b / c;

		System.out.println(d);

		int x = (1 - 5) * (2 - 7);
		double w = x / 2;
		double y = Math.pow(w, 2);

		System.out.println(y);

		double k = d - y;
		double l = 10;
		double m = Math.pow(k, 3);
		double n = Math.pow(l, 3);

		System.out.println(k);
		System.out.println(l);
		System.out.println(m / n);

	}
}
