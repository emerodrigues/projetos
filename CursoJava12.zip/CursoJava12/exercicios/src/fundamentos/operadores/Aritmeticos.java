package fundamentos.operadores;

public class Aritmeticos {

	public static void main(String[] args) {
		
		var x = 34.56;
		double y = 2.2;
		
		System.out.println(x + y);
		System.out.println(x - y);
		System.out.println(x * y);
		System.out.println(x / y);
		
		int a = 8;
		int b = 3;
		
		System.out.println(a + b);
		System.out.println(a - b);
		System.out.println(a * b);
		// converter o inteiro para double
		System.out.println(a / (double) b);
		
		// resto da divisao 'modulo'
		System.out.println(a % b);
		System.out.println(a * b + (x - y));
		
	}
}
