package fundamentos.operadores;

public class DesafioLogicos {

	public static void main(String[] args) {
		
		// Trabalho na ter�a (V ou F)
		// Trabalho na quinta (V ou F)
		
		// TV de 50 se VV 
		// TV de 32 se VF 
		// Sorvete nas duas condi��es
		// Ficar em casa 
		// fazer nega��o
		
		boolean trabalho1 = true;
		boolean trabalho2 = false;
		boolean tv50 = trabalho1 && trabalho2;
		boolean tv32 = trabalho1 ^ trabalho2;
		boolean tomouSorvete = trabalho1 || trabalho2;
		boolean maisSaudavel = !tomouSorvete;
		
		System.out.println("Comprou TV 50\n" 
				+ tv50);
		
		System.out.println("Comprou TV 32\n" 
				+ tv32 );
		
		System.out.println("Comprou sorvete? \n" 
				+ tomouSorvete);
		
		System.out.println("Est� saud�vel? " 
				+ maisSaudavel);
		
		
		
	}
}
