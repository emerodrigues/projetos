package fundamentos;

import javax.swing.JOptionPane;

public class DesafioCalculadora {

	public static void main(String[] args) {
		// Ler num1
		// Ler num2
		// Pedir ao usuario + ou - * ou / ou %
		
		String num1 = JOptionPane.showInputDialog(
				"Digite o numero 1: ");	
		
		String num2 = JOptionPane.showInputDialog(
				"Digite o numero 2:");
	
		double valor1 = Double.parseDouble(num1);
		double valor2 = Double.parseDouble(num2);
		double soma = valor1 + valor2;
		
		
		System.out.println("Valor um �: " + valor1);
		System.out.println("Valor dois �: " + valor2);
		System.out.println("Soma dos dois valores �: " + soma);
	}
}
