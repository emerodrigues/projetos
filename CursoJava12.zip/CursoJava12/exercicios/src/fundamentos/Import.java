package fundamentos;

import java.util.Date;

public class Import {

	public static void main(String[] args) {
		
		Date d = new Date();
		System.out.println(d);
	
		
	}
}
