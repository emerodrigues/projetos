package fundamentos;

public class PrimitivoVsObjeto {
	
	public static void main(String[] args) {
		
		// Wrappers sao a versao objeto dos tipos primitivos
	}
}
