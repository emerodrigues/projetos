package fundamentos;

import java.util.Scanner;

public class Console {
	
	public static void main(String[] args) {
//		System.out.print("Bom\n");
//		System.out.println(" Dia");
//		
//		System.out.printf("Mega Sena: %d, %d, %d, %d, %d, %d",
//				1, 2, 3, 4, 5, 6);
//		
//		System.out.printf("Salario: %.1f", 1234.5678);
//		System.out.printf("Salario: %s", "Joao");
		
		Scanner entrada = new Scanner(System.in);
		System.out.print("Digite o seu nome: ");
		String nome = entrada.nextLine();
		
		System.out.print("Digite sua idade: ");
		int idade = entrada.nextInt();
		
		System.out.println("Nome = " + nome);
		System.out.println("Idade: " + idade);
		
		entrada.close();
		
	}
}
