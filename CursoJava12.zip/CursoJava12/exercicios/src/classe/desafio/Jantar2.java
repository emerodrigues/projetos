package classe.desafio;

public class Jantar2 {

	public static void main(String[] args) {
		
		// criar 2 comidas e 2 pessoas 
		// pessoa come comida 
		// mostrar peso antes de comer e depois de comer

		Comida c1 = new Comida("Carne", 0.500);
		Comida c2 = new Comida("Feijao", 0.500);
		
		Pessoa p1 = new Pessoa("Emerson Silva", 70.100);
		Pessoa p2 = new Pessoa("Michel Silva", 77.500);
		
		double somaPeso1 = p1.peso + c1.peso;
		double somaPeso2 = p2.peso + c2.peso;
		
		
		System.out.println(
				"O peso do " + p1.nome + " �: " + p1.peso);
		System.out.println(
				"\nO peso do " + p1.nome + " Ap�s comer �: " + somaPeso1);
		
		System.out.println(
				"\nO peso do " + p2.nome + " �: " + p2.peso);
		
		System.out.println(
				"\nO peso do " + p2.nome + " Ap�s comer �: " + somaPeso2);
	}
}
