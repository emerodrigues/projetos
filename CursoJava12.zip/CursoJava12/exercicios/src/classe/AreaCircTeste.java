package classe;

public class AreaCircTeste {

	public static void main(String[] args) {

		AreaCirc a = new AreaCirc(8);
		
		// para alterar o valor de PI caso n tenha o final
		//AreaCirc.pi = 3.1415;
		
		System.out.println(a.area());
	}

}
