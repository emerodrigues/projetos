package classe;

public class Data {
	
	int dia;
	int mes;
	int ano;
	
	// criar 2 construtores 
	
	Data() {
//		dia = 1;
//		mes = 1;;
//		ano = 1970;
		
		this(1, 1, 1970);
	}
	
	Data(int dia, int mesInicial, int anoInicial) {
		this.dia = dia;
		this.mes = mesInicial;
		ano = anoInicial;
	}
	
	String obterDataFormatada() {
		final String formato = "%d/%d/%d";
		return String.format(formato, this.dia, mes, ano);
	}
	
	void imprimirDataFormatada() {
		System.out.printf("%d/%d/%d", dia, mes, ano);
	//	System.out.println(obterDataFormatada());
	}
}
