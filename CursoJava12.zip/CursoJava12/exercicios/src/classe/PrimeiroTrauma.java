package classe;

public class PrimeiroTrauma {
	/**
	 * sempre que tentar acessar uma variavel em uma metodo main 
	 * precisa ser instanciado (inicializado) atrav�s do new .. 
	 * 
	 */
	int a = 3; 
	static int b = 4;

	public static void main(String[] args) {
			
		PrimeiroTrauma p = new PrimeiroTrauma();
		System.out.println(p.a);
		
		System.out.println(b);
	}
}
