package classe;

public class ProdutoTeste {
	
	public static void main(String[] args) {
		
		Produto Objetop1 = new Produto("Notebook", 4356.89);
		
		var p2 = new Produto();
		p2.nome = "Caneta Preta";
		p2.preco = 12.56;
		
		Produto.desconto = 0.35;
		
		System.out.println(Objetop1.nome +  " " + Objetop1.precoComDesconto());
		System.out.println(p2.nome + " " + p2.precoComDesconto());
		
//		double precoFinal1 = Objetop1.preco * (1 - Objetop1.desconto);
//		double precoFinal2 = p2.preco * (1 - p2.desconto);
		
		double precoFinal1 = Objetop1.precoComDesconto();
		double precoFinal2 = p2.precoComDesconto(0.1);
		
		System.out.println((precoFinal1 + precoFinal2 ) / 2);
	}
}
