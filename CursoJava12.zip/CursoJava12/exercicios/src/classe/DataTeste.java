package classe;

public class DataTeste {

	public static void main(String[] args) {

		Data d1 = new Data();
		
		var d2 = new Data(22,12,2020);
//		d2.dia = 21;
//		d2.mes = 12;
//		d2.ano = 2020;
		
		//melhor opcao
		System.out.println(d1.obterDataFormatada());

		d2.imprimirDataFormatada();
	}

}
