package lambdas;

public class Somar implements Calculo {
	
	@Override
	public double executar(Double a, Double b) {
		return a + b;
	}
}
