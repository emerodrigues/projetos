package lambdas;

@FunctionalInterface

/**
 * 
 * @author emerodrigues
 * Interface funcional s� pode ter 1 m�todo
 *
 */

public interface Calculo {
	
	// ou double executar(Double a, Double b);
	public abstract double executar(Double a, Double b);
	
	default String legal() {
		return "legal";
	}
	
	
	// static � da classe
	static String muitoLegal() {
		return "muito legal";
	}
}
