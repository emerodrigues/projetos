package lambdas;

public class CalculoTeste {

	public static void main(String[] args) {
		
		Calculo calculo = new Somar();
		System.out.println(calculo.executar(2.0, 4.0));
		
		calculo = new Multiplicar();
		System.out.println(calculo.executar(2.0, 4.0));
		
	}
}
