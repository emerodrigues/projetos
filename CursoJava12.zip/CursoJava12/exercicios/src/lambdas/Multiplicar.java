package lambdas;

public class Multiplicar implements Calculo {
	
	@Override
	public double executar(Double a, Double b) {
		return a * b;
	}
}
