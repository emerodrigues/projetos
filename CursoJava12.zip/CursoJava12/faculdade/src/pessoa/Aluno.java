package pessoa;

public class Aluno {

}
