package educacional;

public class Prova {

}
